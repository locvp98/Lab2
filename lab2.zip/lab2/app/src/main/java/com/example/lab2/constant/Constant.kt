package com.example.lab2.constant

object Constant {

    val BASE_URL = ""
}